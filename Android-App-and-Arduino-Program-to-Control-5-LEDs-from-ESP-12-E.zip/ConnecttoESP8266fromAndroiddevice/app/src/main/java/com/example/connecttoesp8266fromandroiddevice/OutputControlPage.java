package com.example.connecttoesp8266fromandroiddevice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class OutputControlPage extends AppCompatActivity {

    WifiManager wifiManager;
    TextView titleTextView;
    ToggleButton output4Button;
    ToggleButton output12Button;
    ToggleButton output13Button;
    ToggleButton output14Button;
    ToggleButton output16Button;

    IntentFilter intentFilter;

    MyClientTask output4Task, output12Task, output13Task, output14Task, output16Task;

    OutputControlPageBroadcastReceiver outputControlPageBroadcastReceiver;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.output_control_page);

        titleTextView = (TextView) findViewById(R.id.Title);
        output4Button = (ToggleButton) findViewById(R.id.output1Button);
        output12Button = (ToggleButton) findViewById(R.id.output2Button);
        output13Button = (ToggleButton) findViewById(R.id.output3Button);
        output14Button = (ToggleButton) findViewById(R.id.output4Button);
        output16Button = (ToggleButton) findViewById(R.id.output5Button);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);


        output4Button.setChecked(false);
        output12Button.setChecked(false);
        output13Button.setChecked(false);
        output14Button.setChecked(false);
        output16Button.setChecked(false);

        offLeds();

        output4Button.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    output4Task = new MyClientTask("OnLED1");
                    output4Task.execute();
                } else {
                    output4Task = new MyClientTask("OffLED1");
                    output4Task.execute();
                }
            }
        });

        output12Button.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    output12Task = new MyClientTask("OnLED2");
                    output12Task.execute();
                } else {
                    output12Task = new MyClientTask("OffLED2");
                    output12Task.execute();
                }
            }
        });

        output13Button.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    output13Task = new MyClientTask("OnLED3");
                    output13Task.execute();
                } else {
                    output13Task = new MyClientTask("OffLED3");
                    output13Task.execute();
                }
            }
        });

        output14Button.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    output14Task = new MyClientTask("OnLED4");
                    output14Task.execute();
                } else {
                    output14Task = new MyClientTask("OffLED4");
                    output14Task.execute();
                }
            }
        });

        output16Button.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    output16Task = new MyClientTask("OnLED5");
                    output16Task.execute();
                } else {
                    output16Task = new MyClientTask("OffLED5");
                    output16Task.execute();
                }
            }
        });

        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        outputControlPageBroadcastReceiver = new OutputControlPageBroadcastReceiver();
    }

    public class MyClientTask extends AsyncTask<String, String, String> {

        String address;

        public MyClientTask(String address) {
            this.address = address;
        }

        @Override
        protected String doInBackground(String... strings) {
            final StringBuffer chain = new StringBuffer("");
            String serverResponse = "";
            final String p = "http://192.168.4.1/"+address;
            String line = "";

            try {
                URL url = new URL(p);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            } catch (IOException e) {
                e.printStackTrace();
                serverResponse = e.getMessage();
            }

            return serverResponse;
        }
    }

    public class OutputControlPageBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            String action = intent.getAction();
            String SSIDtemp = "PaulESP";
            if(WifiManager.NETWORK_STATE_CHANGED_ACTION.equals(action)) {
                if(wifiManager.getConnectionInfo().getSSID().equals(String.format("\"%s\"", SSIDtemp))) {
                    titleTextView.setText("Connected to PaulESP");
                } else {
                    titleTextView.setText("Device disconnected...");
                }
            }
        }
    }

    private void offLeds() {
        output4Task = new MyClientTask("OffLED1");
        output4Task.execute();

        output12Task = new MyClientTask("OffLED2");
        output12Task.execute();

        output13Task = new MyClientTask("OffLED3");
        output13Task.execute();

        output14Task = new MyClientTask("OffLED4");
        output14Task.execute();

        output16Task = new MyClientTask("OffLED5");
        output16Task.execute();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(outputControlPageBroadcastReceiver);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(outputControlPageBroadcastReceiver, intentFilter);
    }

}
