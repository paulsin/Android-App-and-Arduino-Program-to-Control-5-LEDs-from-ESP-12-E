package com.example.connecttoesp8266fromandroiddevice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ThreadLocalRandom;

public class DevicePage extends AppCompatActivity {

    Button OnButton, OffButton, readAnalogValueButton, stopReadAnalogValue;
    TextView analogValue;
    MyClientTask onLedTask, offLedTask;
    readAnalogValueTask readValueTask;
    WifiManager wifiManager;
    DeviceBroadcastReceiver deviceBroadcastReceiver;
    IntentFilter intentFilter;
    ProgressBar progressBar;
    ToggleButton toggleButton;

    int globalUpperLimit = 0, globalLowerLimit = 0;

    private static final String MSG_KEY = "Yo";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        String SSIDfromIntent = getIntent().getExtras().getString("SSID");
        deviceBroadcastReceiver = new DeviceBroadcastReceiver();

        Toast.makeText(this, SSIDfromIntent, Toast.LENGTH_SHORT).show();
        intentFilter = new IntentFilter();

        intentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);

        setContentView(R.layout.devicepage);

        OnButton = (Button) findViewById(R.id.On);
        OffButton = (Button) findViewById(R.id.Off);
        readAnalogValueButton = (Button) findViewById(R.id.readAnalogValue);
        analogValue = (TextView) findViewById(R.id.analogValue);
        stopReadAnalogValue = (Button) findViewById(R.id.stopReadAnalogValue);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        toggleButton = (ToggleButton) findViewById(R.id.toggleButton);

        OnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onLedTask = new MyClientTask("OnLED");
                onLedTask.execute();
            }
        });

        OffButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                offLedTask = new MyClientTask("OffLED");
                offLedTask.execute();
            }
        });

        readAnalogValueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //readValueTask = new readAnalogValueTask();
                //readValueTask.execute();

                OnOffThread onOffThread = new OnOffThread("AnalogRead");
                onOffThread.start();
            }
        });

        stopReadAnalogValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    onLedTask = new MyClientTask("OnLED");
                    onLedTask.execute();
                } else {
                    offLedTask = new MyClientTask("OffLED");
                    offLedTask.execute();
                }
            }
        });
    }

    public class MyClientTask extends AsyncTask<String, Void, String>{

        String addressValue;

        public MyClientTask(String address) {
            this.addressValue = address;
        }

         @Override
         protected String doInBackground(String... params) {

            final StringBuffer chain = new StringBuffer("");
            String serverResponse = "";
            final String p = "http://192.168.4.1/"+addressValue;
            String line = "";

            try {
                URL url = new URL(p);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));

                while ((line = rd.readLine()) != null) {
                    chain.append(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
                serverResponse = e.getMessage();
            }

            if(addressValue == "AnalogRead") {

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        analogValue.setText(chain.toString());
                        //analogReadLoop = new AnalogReadLoop(chain.toString());
                        //analogReadLoop.start();
                    }
                });
            }

            return serverResponse;
         }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
    }

    public class readAnalogValueTask extends AsyncTask<String, String, String> {

        String address = "AnalogRead";
        int upperLimit = 0;
        int lowerLimit = 0;
        int i = 0;

        @Override
        protected String doInBackground(String... strings) {

            final StringBuffer chain = new StringBuffer("");
            String serverResponse = "";
            final String p = "http://192.168.4.1/"+address;
            String line = "";

            boolean refer = true;
            String SSIDtemp = "PaulESP";
            while (wifiManager.getConnectionInfo().getSSID().equals(String.format("\"%s\"", SSIDtemp))){

                try {
                    chain.delete(0, chain.length());
                    URL url = new URL(p);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));

                    while ((line = rd.readLine()) != null) {
                        chain.append(line);
                    }

                    serverResponse = chain.toString();

                    upperLimit = Integer.parseInt(chain.toString());

                    //  lower limit   upper limit     entered
                    //      0           100             100
                    //     100          500             500
                    //     500          200             200
                    //     200          800             800

                    if(upperLimit > lowerLimit) {
                        for (i = lowerLimit; i <= upperLimit; i = i + 1) {
                            publishProgress(String.valueOf(i));
                            Thread.sleep(1);
                        }
                        lowerLimit = upperLimit;
                    } else if (upperLimit < lowerLimit) {
                        for (i = lowerLimit; i >= upperLimit; i = i - 1) {
                            publishProgress(String.valueOf(i));
                            Thread.sleep(1);
                        }
                        lowerLimit = upperLimit;
                    }

                    //publishProgress(chain.toString());
                    Thread.sleep(2000);

                } catch (IOException e) {
                    e.printStackTrace();
                    serverResponse = e.getMessage();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    serverResponse = e.getMessage();
                }
            }

            return serverResponse;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            analogValue.setText(s);
        }

        @Override
        protected void onProgressUpdate(String... values) {
            analogValue.setText(values[0]);
            progressBar.setProgress(Integer.parseInt(values[0]));
        }
    }

    private Handler onOffButtonHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            String progressValue = bundle.getString("progressValue");
            String progress = bundle.getString("progress");
            analogValue.setText(progressValue);
            progressBar.setProgress(Integer.parseInt(progressValue));
        }
    };

    private class OnOffThread extends Thread {

        String addressValue;
        int upperLimit = 0, lowerLimit = 0, i = 0;
        public OnOffThread(String addressValue) {
            this.addressValue = addressValue;
        }

        @Override
        public void run() {
            final StringBuffer chain = new StringBuffer("");
            String analogValue = "";
            final String p = "http://192.168.4.1/"+addressValue;
            String line = "";

            for(int count =0; count <100 ; count++) {

                chain.delete(0, chain.length());
                try {
                    URL url = new URL(p);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));

                    while ((line = rd.readLine()) != null) {
                        chain.append(line);
                    }

                    analogValue = chain.toString();

                    upperLimit = Integer.parseInt(chain.toString());

                    //  lower limit   upper limit     entered
                    //      0           100             100
                    //     100          500             500
                    //     500          200             200
                    //     200          800             800


                    /*
                    if (upperLimit > lowerLimit) {
                        for (i = lowerLimit; i <= upperLimit; i = i + 1) {
                            Message msg = onOffButtonHandler.obtainMessage();
                            Bundle bundle = new Bundle();
                            bundle.putString("progressValue", serverResponse);
                            bundle.putString("progress", String.valueOf(i));
                            msg.setData(bundle);
                            onOffButtonHandler.sendMessage(msg);
                        }
                        lowerLimit = upperLimit;
                    } else if (upperLimit < lowerLimit) {
                        for (i = lowerLimit; i >= upperLimit; i = i - 1) {
                            Message msg = onOffButtonHandler.obtainMessage();
                            Bundle bundle = new Bundle();
                            bundle.putString("progressValue", serverResponse);
                            bundle.putString("progress", String.valueOf(i));
                            msg.setData(bundle);
                            onOffButtonHandler.sendMessage(msg);
                        }
                        lowerLimit = upperLimit;
                    }

                    */

                    ThreadAsyncTask threadAsyncTask = new ThreadAsyncTask();
                    threadAsyncTask.execute(analogValue);

                    Thread.sleep(3000);

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public class ThreadAsyncTask extends AsyncTask<String, String, String> {

        String serverResponse = "";
        int lowerLimit =0;
        int upperLimit = 0;
        int i = 0;

        @Override
        protected String doInBackground(String... strings) {

            try {
                globalUpperLimit = Integer.parseInt(strings[0]);

                if (globalUpperLimit > globalLowerLimit) {
                    for (i = globalLowerLimit; i <= globalUpperLimit; i = i + 1) {
                        publishProgress(String.valueOf(i));
                        Thread.sleep(1);
                    }
                    globalLowerLimit = globalUpperLimit;
                } else if (globalUpperLimit < globalLowerLimit) {
                    for (i = globalLowerLimit; i >= globalUpperLimit; i = i - 1) {
                        publishProgress(String.valueOf(i));
                        Thread.sleep(1);
                    }
                    globalLowerLimit = globalUpperLimit;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return serverResponse;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            analogValue.setText(values[0]);
            progressBar.setProgress(Integer.parseInt(values[0]));
        }
    }

    public class DeviceBroadcastReceiver extends BroadcastReceiver {
         @Override
         public void onReceive(Context context, Intent intent) {

             String action = intent.getAction();
             String SSIDtemp = "PaulESP";
             if(WifiManager.NETWORK_STATE_CHANGED_ACTION.equals(action)) {
                 if (wifiManager.getConnectionInfo().getSSID().equals(String.format("\"%s\"", SSIDtemp))) {
                     OnButton.setText("ON");
                     OffButton.setText("OFF");

                     OffButton.setEnabled(true);
                     OnButton.setEnabled(true);
                     //Toast.makeText(DevicePage.this, "In the function...", Toast.LENGTH_SHORT).show();
                 } else {
                     OnButton.setText("Disconnected...");
                     OffButton.setText("Disconnected...");
                     OffButton.setEnabled(false);
                     OnButton.setEnabled(false);
                     //Toast.makeText(DevicePage.this, "Out of function...", Toast.LENGTH_SHORT).show();
                 }
             }
         }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(deviceBroadcastReceiver, intentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(deviceBroadcastReceiver);
    }
}
