package com.example.connecttoesp8266fromandroiddevice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    WifiManager wifiManager;
    Button OnOffButton, SearchButton;
    ListView wifiDeviceList;
    String[] SSIDarray;
    String wifiPassword;
    TextView WifiSSIDpassPrompt;
    TextView connectingStatus;
    WifiConfiguration wifiConfiguration;

    EditText passwordFromPrompt;
    WiFiBroadcastReceiver wiFiBroadcastReceiver = new WiFiBroadcastReceiver();

    IntentFilter intentFilter;
    List <ScanResult> wifiScanResult = new ArrayList<ScanResult>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        OnOffButton = (Button) findViewById(R.id.OnOff);

        SearchButton = (Button) findViewById(R.id.searchWiFi);
        wifiDeviceList = (ListView) findViewById(R.id.wifiDevices);

        connectingStatus = (TextView) findViewById(R.id.connectingStatus);

        intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);

        Initialize();
        exqListener();
    }

    private void exqListener() {
        OnOffButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(wifiManager.isWifiEnabled()) {
                    wifiManager.setWifiEnabled(false);
                    OnOffButton.setText("WiFi Status : OFF");
                } else if (!wifiManager.isWifiEnabled()) {
                    wifiManager.setWifiEnabled(true);
                    OnOffButton.setText("WiFi Status : ON");
                }
            }
        });

        SearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(wifiManager.isWifiEnabled()) {
                    wifiManager.startScan();
                } else {
                    Toast.makeText(getApplicationContext(), "Turn On WiFi", Toast.LENGTH_SHORT).show();
                }
            }
        });

        wifiDeviceList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {

                //Intent intent = new Intent(MainActivity.this, DevicePage.class);
                //startActivity(intent);
                //wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                String quotedText = String.format("\"%s\"", SSIDarray[position]);
                //Toast.makeText(MainActivity.this, quotedText, Toast.LENGTH_SHORT).show();
                if(wifiInfo.getSSID().equals(quotedText))
                {
                    Intent intent = new Intent(MainActivity.this, OutputControlPage.class);
                    intent.putExtra("SSID", quotedText);
                    startActivity(intent);
                }
                else
                {
                    LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                    final View promptView = inflater.inflate(R.layout.passwordprompt, null);

                    WifiSSIDpassPrompt = (TextView) promptView.findViewById(R.id.WiFiSSID);
                    WifiSSIDpassPrompt.setText(SSIDarray[position]);
                    passwordFromPrompt = (EditText) promptView.findViewById(R.id.passwordInput);

                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setView(promptView);

                    builder.setCancelable(true).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    }).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String password = passwordFromPrompt.getText().toString();
                            connectWiFi(SSIDarray[position], password);
                        }
                    });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            }
        });
    }

    private void Initialize() {
        if(wifiManager.isWifiEnabled()) {
            wifiManager.setWifiEnabled(false);
            OnOffButton.setText("WiFi Status : OFF");
        } else if (!wifiManager.isWifiEnabled()) {
            wifiManager.setWifiEnabled(true);
            OnOffButton.setText("WiFi Status : ON");
        }
    }

    public void connectWiFi(String SSID, String password) {

        wifiConfiguration = new WifiConfiguration();
        wifiConfiguration.SSID = String.format("\"%s\"", SSID);
        wifiConfiguration.preSharedKey = String.format("\"%s\"", password);
        int netID = wifiManager.addNetwork(wifiConfiguration);

        wifiManager.disconnect();
        wifiManager.enableNetwork(netID, true);
        wifiManager.reconnect();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WifiInfo wifiInfo = wifiManager.getConnectionInfo();

        //Toast.makeText(MainActivity.this, wifiInfo.getSSID(), Toast.LENGTH_SHORT).show();

        if(wifiInfo.getSSID().equals(String.format("\"%s\"", SSID))) {
            Toast.makeText(MainActivity.this, "Connected to "+SSID, Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, OutputControlPage.class);
            String quotedText = String.format("\"%s\"", SSID);
            intent.putExtra("SSID", quotedText);
            startActivity(intent);
        } else {
            Toast.makeText(MainActivity.this, "Connecting failed...", Toast.LENGTH_SHORT).show();
        }
    }

    public void createScanResult() {

        wifiScanResult = wifiManager.getScanResults();
        SSIDarray = new String[wifiScanResult.size()];

        int index = 0;
        for (ScanResult result : wifiScanResult) {
            SSIDarray[index] = result.SSID;
            index++;
        }

        ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, SSIDarray);
        wifiDeviceList.setAdapter(adapter);
    }

    class WiFiBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equals(action)) {
                if (wifiManager.isWifiEnabled()) {
                    createScanResult();
                } else {
                    Toast.makeText(getApplicationContext(), "WiFi is OFF", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(wiFiBroadcastReceiver, intentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(wiFiBroadcastReceiver);
    }
}
